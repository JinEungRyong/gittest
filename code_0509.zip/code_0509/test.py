import evdev
from evdev import InputDevice, categorize, ecodes
device = evdev.InputDevice('/dev/input/event0')
print(device)

get_touch = 0

for event in device.read_loop():
    if event.type == ecodes.EV_ABS:
        #print(event)
        if event.code == 57:
            if event.value != -1:
                t_id=event.value
                #t_id_time = event.time
                get_touch+=1
                #print(event.value)
        elif event.code == 53:
            t_x = event.value
            #t_x_time = event.time
            get_touch+=1
            #print(event.value)
        elif event.code == 54:
            t_y = event.value
            #t_y_time = event.time
            get_touch+=1
            #print(event.value)
    if(get_touch == 3):
        #if(t_id_time == t_x_time and t_id_time == t_y_time):
        print('id :',t_id,' x:',t_x,' y:',t_y)
        get_touch=0
        
